# 1. Reading and Writing Plain Text Files Example[cite: 1]
with open("example.txt", "w", encoding="utf-8") as file:
    file.write("Hello, World!\n")
    file.write("This is a second line of text.")

with open("example.txt", "a", encoding="utf-8") as file:
    file.write("\nThis line was appended.")

with open("example.txt", "r", encoding="utf-8") as file:
    content = file.read()
    print("--- Entire File Content ---")
    print(content)

with open("example.txt", "r", encoding="utf-8") as file:
    print("--- Line by Line ---")
    for line in file:
        print(line.strip())
