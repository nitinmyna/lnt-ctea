# 2. Working with CSV (Comma-Separated Values) Data[cite: 1]
import csv

data = [
    ["Name", "Age", "Profession"],
    ["Alice", 30, "Engineer"],
    ["Bob", 25, "Designer"],
    ["Charlie", 35, "Manager"],
]

# Writing to CSV[cite: 1]
with open("people.csv", "w", newline="", encoding="utf-8") as file:
    writer = csv.writer(file)
    writer.writerows(data)

# Reading from CSV using DictReader[cite: 1]
with open("people.csv", "r", encoding="utf-8") as file:
    reader = csv.DictReader(file)
    for row in reader:
        print(f"{row['Name']} is {row['Age']} years old and works as a {row['Profession']}.")
