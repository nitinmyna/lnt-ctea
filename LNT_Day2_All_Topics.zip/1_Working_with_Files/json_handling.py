# 3. Working with JSON (JavaScript Object Notation) Data[cite: 1]
import json

data = {
    "user": "Alice",
    "id": 1042,
    "active": True,
    "skills": ["Python", "SQL", "Git"],
}

# Writing JSON Data[cite: 1]
with open("config.json", "w", encoding="utf-8") as file:
    json.dump(data, file, indent=4)

# Reading JSON Data[cite: 1]
with open("config.json", "r", encoding="utf-8") as file:
    loaded_data = json.load(file)

print("User:", loaded_data["user"])
print("Skills:", loaded_data["skills"])
