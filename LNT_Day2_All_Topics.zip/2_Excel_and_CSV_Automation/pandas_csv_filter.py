# Automating CSV Tasks with pandas: Filtering High Earners[cite: 1]
import pandas as pd

sample_data = "Name,Department,Salary\nAlice,Engineering,75000\nBob,Marketing,45000\nCharlie,Engineering,90000\nDiana,HR,48000"
with open("employees.csv", "w", encoding="utf-8") as f:
    f.write(sample_data)

df = pd.read_csv("employees.csv")
high_earners = df[df["Salary"] >= 50000]
high_earners.to_csv("high_earners.csv", index=False)
print("Filtered data saved successfully!")
print(high_earners)
