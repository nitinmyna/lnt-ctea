# Automating Excel Workbooks with openpyxl[cite: 1]
import openpyxl

wb = openpyxl.Workbook()
ws = wb.active
ws.title = "Expenses"

ws["A1"] = "Item"
ws["B1"] = "Cost"

expenses = [
    ["Rent", 1200],
    ["Utilities", 150],
    ["Internet", 60],
]

for row_idx, item in enumerate(expenses, start=2):
    ws.cell(row=row_idx, column=1, value=item[0])
    ws.cell(row=row_idx, column=2, value=item[1])

ws["A5"] = "Total"
ws["B5"] = "=SUM(B2:B4)"

wb.save("monthly_expenses.xlsx")
print("Excel spreadsheet created successfully!")
