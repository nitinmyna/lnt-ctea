# Data Analysis: Cleaning, Filtering, and Summarizing Data with Pandas[cite: 1]
import pandas as pd

sales_csv = "Order_ID,Customer,Region,Category,Sales,Quantity,Date\n1,John,North,Electronics,600,2,2026-01-01\n2,Sarah,East,Clothing,200,1,2026-01-05\n3,Mike,North,Electronics,800,3,2026-01-10"
with open("sales_data.csv", "w", encoding="utf-8") as f:
    f.write(sales_csv)

df = pd.read_csv("sales_data.csv")

print("--- Head ---")
print(df.head())
print("\n--- Info ---")
print(df.info())

north_sales = df[df["Region"] == "North"]
print("\n--- North Sales ---")
print(north_sales)

sales_by_region = df.groupby("Region")["Sales"].sum().reset_index()
print("\n--- Sales by Region ---")
print(sales_by_region)
