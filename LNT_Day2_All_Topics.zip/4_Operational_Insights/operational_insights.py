# Operational Insights: Pareto Analysis, Churn, and Trends[cite: 1]
import pandas as pd

data = "Order_ID,Customer_ID,Product,Revenue,Date,Delivery_Days\n101,C001,Laptop,1200,2026-05-01,3\n102,C002,Mouse,25,2026-05-02,2\n103,C001,Monitor,300,2026-05-03,12"
with open("sales_data.csv", "w", encoding="utf-8") as f:
    f.write(data)

df = pd.read_csv("sales_data.csv")

top_products = (
    df.groupby("Product")["Revenue"]
    .sum()
    .reset_index()
    .sort_values(by="Revenue", ascending=False)
)
print("Top Products by Revenue:")
print(top_products)

mean_delivery_days = df["Delivery_Days"].mean()
threshold = mean_delivery_days * 1.5
delayed_orders = df[df["Delivery_Days"] > threshold]
print(f"Alert: {len(delayed_orders)} orders experienced abnormal delays.")
