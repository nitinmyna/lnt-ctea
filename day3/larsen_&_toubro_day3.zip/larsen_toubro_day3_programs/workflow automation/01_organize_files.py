import os
import shutil
folder = "Documents"
os.makedirs(folder, exist_ok=True)
for file in os.listdir(folder):
    file_path = os.path.join(folder, file)
    if os.path.isfile(file_path):
        extension = file.split(".")[-1].lower()
        if extension == "pdf":
            destination = "Documents/PDF"
        elif extension in ["jpg", "png", "jpeg"]:
            destination = "Documents/Images"
        elif extension in ["xlsx", "csv"]:
            destination = "Documents/Excel"
        elif extension == "txt":
            destination = "Documents/Text"
        else:
            continue
        os.makedirs(destination, exist_ok=True)
        shutil.move(file_path, destination)
print("Files organized successfully!")