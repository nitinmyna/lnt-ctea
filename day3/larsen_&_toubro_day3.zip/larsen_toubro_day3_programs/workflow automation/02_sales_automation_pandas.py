import pandas as pd
data = {"Quantity": [2, 10, 5, 3], "Price": [50000, 800, 1500, 12000]}
df = pd.DataFrame(data)
df["Total"] = df["Quantity"] * df["Price"]
total_sales = df["Total"].sum()
print("Total Sales:", total_sales)
df.to_csv("processed_sales.csv", index=False)