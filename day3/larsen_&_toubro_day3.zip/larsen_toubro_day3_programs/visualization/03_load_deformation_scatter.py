import matplotlib.pyplot as plt
load = [10, 20, 30, 40, 50]
deformation = [2, 4, 6, 8, 10]
plt.scatter(load, deformation)
plt.title("Load vs Deformation")
plt.xlabel("Load (kN)")
plt.ylabel("Deformation (mm)")
plt.show()