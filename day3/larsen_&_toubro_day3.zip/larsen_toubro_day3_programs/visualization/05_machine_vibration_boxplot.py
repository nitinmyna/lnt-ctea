import matplotlib.pyplot as plt
vibration = [2.1, 2.3, 2.2, 2.4, 2.0, 2.3, 2.2, 5.8]
plt.boxplot(vibration)
plt.title("Machine Vibration Analysis")
plt.ylabel("Vibration Level")
plt.show()