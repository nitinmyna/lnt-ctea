import seaborn as sns
import matplotlib.pyplot as plt
import pandas as pd
data = {
    "Temperature": [25, 30, 35, 40, 45],
    "Pressure": [10, 12, 15, 18, 20],
    "Efficiency": [95, 92, 88, 84, 80]
}
sns.heatmap(
    pd.DataFrame(data).corr(),
    annot=True
)
plt.title("Engineering Parameter Correlation")
plt.show()