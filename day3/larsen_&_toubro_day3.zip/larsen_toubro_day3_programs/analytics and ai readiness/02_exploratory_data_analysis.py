import pandas as pd
data = {
    "Attendance": [90, 95, 80, 85, 88],
    "Marks": [85, 92, 75, 78, 82]
}
df = pd.DataFrame(data)
print("Statistical Summary:\n", df.describe())
print("Correlation Matrix:\n", df.corr(numeric_only=True))