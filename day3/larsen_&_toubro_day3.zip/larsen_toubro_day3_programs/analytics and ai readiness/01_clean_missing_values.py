import pandas as pd
data = {
    "Name": ["Ravi", "Anu", "Kiran", "Meena"],
    "Marks": [85, 92, None, 78],
    "Attendance": [90, 95, 80, None]
}
df = pd.DataFrame(data)

print("Original DataFrame:\n", df)

print("Missing values:\n", df.isnull().sum())

df["Marks"] = df["Marks"].fillna(df["Marks"].mean())
df["Attendance"] = df["Attendance"].fillna(df["Attendance"].mean())

print("Cleaned DataFrame:\n", df)