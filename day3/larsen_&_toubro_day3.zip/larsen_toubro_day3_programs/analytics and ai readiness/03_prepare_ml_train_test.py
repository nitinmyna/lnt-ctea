import pandas as pd
from sklearn.model_selection import train_test_split
data = {
    "Attendance": [90, 95, 80, 85, 88],
    "Marks": [85, 92, 75, 78, 82]
}
df = pd.DataFrame(data)
X = df[["Attendance"]]
y = df["Marks"]
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42
)
print("X_train:\n", X_train)