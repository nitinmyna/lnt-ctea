import pandas as pd
import matplotlib.pyplot as plt

data = {
    "Date": ["2026-01-01", "2026-01-02", "2026-01-03", "2026-01-04"],
    "Product": ["Laptop", "Mouse", "Keyboard", "Monitor"],
    "Quantity": [2, 10, 5, 3],
    "Price": [50000, 800, 1500, 12000]
}
df = pd.DataFrame(data)
df = df.drop_duplicates()
df["Date"] = pd.to_datetime(df["Date"])
df["Total"] = df["Quantity"] * df["Price"]
total_sales = df["Total"].sum()
product_sales = df.groupby("Product")["Total"].sum()
total_quantity = df["Quantity"].sum()
average_sale = df["Total"].mean()

product_sales.plot(kind="bar")
plt.title("Sales by Product")
plt.xlabel("Product")
plt.ylabel("Sales")
plt.tight_layout()
plt.savefig("sales_chart.png")
plt.close()

df.to_csv("processed_sales.csv", index=False)

with open("sales_report.txt", "w") as file:
    file.write("SALES ANALYTICS REPORT\n")
    file.write(f"Total Sales: {total_sales}\n")
    file.write(f"Total Quantity: {total_quantity}\n")
    file.write(f"Average Sale: {average_sale:.2f}\n")
print("Complete Sales Pipeline Executed Successfully!")