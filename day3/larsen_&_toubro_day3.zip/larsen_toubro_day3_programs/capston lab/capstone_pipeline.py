import os
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression


def run_capstone():

    # Get the folder where this Python file is located
    folder = os.path.dirname(os.path.abspath(__file__))

    # Input file
    sales_file = os.path.join(folder, "sales.csv")

    # Output files
    chart_file = os.path.join(folder, "capstone_chart.png")
    report_file = os.path.join(folder, "capstone_report.txt")

    # -------------------------------
    # 1. READ DATA
    # -------------------------------

    df = pd.read_csv(sales_file)

    print("Data loaded successfully!")
    print("Original records:", len(df))

    # -------------------------------
    # 2. DATA CLEANING
    # -------------------------------

    df = df.drop_duplicates()

    df["Date"] = pd.to_datetime(df["Date"])

    print("Records after removing duplicates:", len(df))

    # -------------------------------
    # 3. CALCULATE REVENUE
    # -------------------------------

    df["Total_Revenue"] = df["Quantity"] * df["Price"]

    total_revenue = df["Total_Revenue"].sum()

    # -------------------------------
    # 4. PRODUCT ANALYTICS
    # -------------------------------

    product_rev = df.groupby("Product")["Total_Revenue"].sum()

    print("\nRevenue by Product:")
    print(product_rev)

    # -------------------------------
    # 5. CREATE CHART
    # -------------------------------

    product_rev.plot(
        kind="bar",
        color="purple"
    )

    plt.title("Capstone Revenue by Product")
    plt.xlabel("Product")
    plt.ylabel("Total Revenue")
    plt.xticks(rotation=45)
    plt.tight_layout()

    plt.savefig(chart_file)
    plt.close()

    # -------------------------------
    # 6. MACHINE LEARNING
    # -------------------------------

    X = df[["Quantity"]]
    y = df["Total_Revenue"]

    X_train, X_test, y_train, y_test = train_test_split(
        X,
        y,
        test_size=0.2,
        random_state=42
    )

    model = LinearRegression()

    model.fit(X_train, y_train)

    # Make predictions
    predictions = model.predict(X_test)

    # -------------------------------
    # 7. MODEL INFORMATION
    # -------------------------------

    r2_score = model.score(X_test, y_test)

    # -------------------------------
    # 8. GENERATE REPORT
    # -------------------------------

    with open(report_file, "w") as f:

        f.write("CAPSTONE LAB REPORT\n")
        f.write("===================\n\n")

        f.write(f"Total Records: {len(df)}\n")
        f.write(f"Total Revenue: {total_revenue:.2f}\n\n")

        f.write("Revenue by Product:\n")
        f.write("-------------------\n")

        for product, revenue in product_rev.items():
            f.write(f"{product}: {revenue:.2f}\n")

        f.write("\nMachine Learning Results:\n")
        f.write("-------------------------\n")
        f.write(f"Model: Linear Regression\n")
        f.write(f"R2 Score: {r2_score:.4f}\n")

    print("\n--------------------------------")
    print("Capstone pipeline completed!")
    print("--------------------------------")
    print("Total Revenue:", total_revenue)
    print("R2 Score:", r2_score)

    print("\nFiles generated:")
    print("1. capstone_chart.png")
    print("2. capstone_report.txt")



run_capstone()